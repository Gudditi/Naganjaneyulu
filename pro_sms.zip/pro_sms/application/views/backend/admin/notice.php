<div class="main_data">
	<?php include 'notice_list.php';?>
</div>