<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html lang="en-US" xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>
	<title>Vivekanand College Photo Gallery</title>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<link rel="shortcut icon" href="../css/images/logo1.png" />
	<link rel="stylesheet" href="../css/style.css" type="text/css" media="all" />
	
	<script src="../js/jquery-1.6.2.min.js" type="text/javascript" charset="utf-8"></script>
	<!--[if IE 6]>
		<script src="../js/DD_belatedPNG-min.js" type="text/javascript" charset="utf-8"></script>
	<![endif]-->
	<script src="../js/cufon-yui.js" type="text/javascript"></script>
	<script src="../js/Myriad_Pro_700.font.js" type="text/javascript"></script>
	<script src="../js/jquery.jcarousel.min.js" type="text/javascript" charset="utf-8"></script>
	<script src="../js/functions.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>
	<!-- Begin Wrapper -->
	
<div id="wrapper">
		<!-- Begin Header -->
		<div id="header">
			
<!-- Begin Shell -->

<body style="margin-bottom:80px;background-color: #c9bda7; 
	background-image: url(../css/images/templatemo_body.jpg);">			
<div class="shell" style="margin-bottom:45px;">
			
<img src="../css/images/logo1.png" width="" height="140" style="margin-bottom:105px;margin-left:-95px;margin-top:30px;">
<H6 style="margin-top:-250px;margin-left:50px;font-size:15px;color:#666666;display: block;">Managed By Abhinav Education Trust, Jahangirpura</h6>
<H6 style="margin-top:-18px;margin-left:600px;font-size:15px;color:#666666;" >Affiliated To Veer Narmad South Gujarat University</h6>
<H6 style="margin-top:40px;margin-left:75px;font-size:32px;color:#666666;font-weight:bold" >VIVEKANAND COLLEGE FOR BCA,BBA,B.COM,B.Ed,PTC </h6>
<br>
<H6 style="margin-top:px;margin-left:px;font-size:14px;color:#666666;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Reg. No.E/4682/SURAT)</h6>			
<script src="../js/jquery-1.6.2.min.js" type="text/javascript" charset="utf-8"></script>
	<!--[if IE 6]>
		
<script src="../js/DD_belatedPNG-min.js" type="text/javascript" charset="utf-8"></script>
	<![endif]-->



<script src="../js/jquery.jcarousel.min.js" type="text/javascript" charset="utf-8"></script>
	
<script src="../js/functions.js" type="text/javascript" charset="utf-8"></script>
</head>


</body>			
<div class="cl">&nbsp;</div>
				
		
</div>
			
<!-- End Shell -->
		
</div>
		<!-- End Header -->
		
<div id="navigation">
			
<!-- Begin Shell -->
			
<div class="shell">
				
<ul>
					
<li ><a href="../index.php" title="home">Home</a></li>

<li ><a href="" title="Kids">About Us</a>

<div class="dd">
							
<ul>
<li><a href="../about/mission.html" title="Drop down menu 1">mission</a></li>
								
<li><a href="../about/college.php" title="Drop down menu 2">college</a></li>
								
<li>
<a href="../about/management.html" title="Drop down menu 3">management</a>
</li>
<li>
<a href="../about/creater.html" title="Drop down menu 3">Developers</a>
</li>	
</ul>
</div>
</li>	
<li><a href="#" title="Sports">Course</a>
<div class="dd">
							
<ul>
<li><a href="" title="Drop down menu 1">BCA</a></li>
								
<li><a href="bba.php" title="Drop down menu 2">BBA</a></li>
								
<li>
<a href="bcom.php" title="Drop down menu 3">BCOM</a>
</li>
<li>
<a href="bed.php" title="Drop down menu 3">BED</a>
</li>
<li>
<a href="ptc.php" title="Drop down menu 3">PTC</a>
</li>			
</ul>
</div>
</li>							
<li><a href="" title="Kids">Faculty</a>

<div class="dd">
							
<ul>
<li><a href="../faculty/bcafaclist.php" title="Drop down menu 1">BCA</a></li>
								
<li><a href="../faculty/bbafaclist.php">BBA</a></li>
								
<li>
<a href="../faculty/bcomfaclist.php" title="Drop down menu 3">BCOM</a>
</li>
<li><a href="../faculty/bedfaclist.php" title="Drop down menu 2">BED</a></li>
								
<li>
<a href="../faculty/ptcfaclist.php" title="Drop down menu 3">PTC</a>
</li>		
</ul>
</div>
</li>						
<li><a href="../result/result.php" title="">Result</a></li>

<li><a href="" title="Kids">Attendance</a>

<div class="dd">
							
<ul>
<li><a href="../attendance/showattendancebca.php" title="Drop down menu 1">BCA</a></li>
								
<li><a href="../attendance/showattendancebba.php" title="Drop down menu 1">BBA</a></li>
						
<li><a href="../attendance/showattendancebcom.php" title="Drop down menu 1">BCOM</a></li>

<li><a href="../attendance/showattendancebed.php" title="Drop down menu 1">BED</a></li>
							
<li><a href="../attendance/showattendanceptc.php" title="Drop down menu 1">PTC</a></li>

</ul>
</div>
</li>		
				


					
<li><a href="#" title="Football">Download</a>
						
<div class="dd">
							
<ul>
								
<li>
<a href="#" title="Drop down menu 3">Exam Time Table</a>
									
<div class="dd">
										
<ul>
											
<li><a href="../download/examtimetable/bcaexamtimetable.php" title="Dr">BCA</a></li>
											
<li><a href="../download/examtimetable/bbaexamtimetable.php" title="Drop down menu 2">BBA</a></li>
											
<li><a href="../download/examtimetable/bcomexamtimetable.php" title="Drop down menu 3">BCOM</a></li>
											
<li><a href="../download/examtimetable/bedexamtimetable.php" title="Drop down menu 4">BED</a></li>

<li><a href="../download/examtimetable/ptcexamtimetable.php" title="Drop down menu 4">PTC</a></li>
											
</ul>
									
</div>
								</li>
								
<li>
<a href="#" title="Drop down menu 3">Syllabus</a>
									
<div class="dd">
										
<ul>
											
<li><a href="../download/syllabus/bcasyllabus.php" title="Dr">BCA</a></li>
											
<li><a href="../download/syllabus/bbasyllabus.php"  title="Drop down menu 2">BBA</a></li>
											
<li><a href="../download/syllabus/bcomsyllabus.php"  title="Drop down menu 3">BCOM</a></li>
											
<li><a href="../download/syllabus/bedsyllabus.php" title="Drop down menu 4">BED</a></li>

<li><a href="../download/syllabus/ptcsyllabus.php" title="Drop down menu 4">PTC</a></li>
											
</ul>
									
</div>
								</li>
								
<li>
<a href="#" title="Drop down menu 3">Assignment</a>
									
<div class="dd">
										
<ul>
											
<li><a href="../download/assignment/bcaassignment.php" title="Dr">BCA</a></li>
											
<li><a href="../download/assignment/bbaassignment.php" title="Dr">BBA</a></li>
											
<li><a href="../download/assignment/bcomassignment.php" title="Dr">BCOM</a></li>
												
<li><a href="../download/assignment/bedassignment.php" title="Dr">BED</a></li>
	
<li><a href="../download/assignment/ptcaasignment.php" title="Dr">PTC</a></li>
										
</ul>
									
</div>
							
</ul>
						
</div>
					
</li>
					
<li class="active"><a href="clggallery.php" title="">Photo Gallery</a>
</li>			
		
			
			
</ul>
				
<div class="cl">&nbsp;</div>
			
</div>
			<!-- End Shell -->
		
</div>
		<!-- End Navigation -->
			
<div id="main" class="shell">
			
<!-- Begin Content -->
	
<br><br>	
<div id="content">

<div class="templatemo_main_top"></div>	
<div class="templatemo_main_wrapperviewallbum">				
<div class="post" style="width:800px;">
<br>
<?php
$id=$_GET['downid'];
$conn = mysql_connect("localhost", "root", "");
mysql_select_db("vvkcollege");
$res=mysql_query("SELECT path,down_title from download_master where down_id=$id;");
$row=mysql_fetch_array($res);
$path=$row['path'];
$ttname=$row['down_title'];
?>					
<center><h2 style="margin-left:50px;margin-top:;font-size:30px;">Vivekanand College <?php echo $ttname?> Photo Gallery</h2></center>	
<br>				
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        <title>Vivekanand College Surat Photo Gallery</title>
        <meta name="keywords" content="" />
        <meta name="description" content="" />
        <link href="styles.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="images/logo1.png" rel="SHORTCUT ICON" type="text/css" media="screen" />
<!-- Pirobox setup and styles -->
<script type="text/javascript" src="lib/jquery-1.3.2.min.js"></script>
<script type="text/javascript" src="lib/pirobox.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	$().piroBox({
			my_speed: 400, //animation speed
			bg_alpha: 0.1, //background opacity
			slideShow : false, // true == slideshow on, false == slideshow off
			slideSpeed : 4, //slideshow duration in seconds(3 to 6 Recommended)
			close_all : '.piro_close,.piro_overlay'// add class .piro_overlay(with comma)if you want overlay click close piroBox

	});
});
</script>

<link href="images/style.css" rel="stylesheet" type="text/css" />


<!-- Pirobox setup and styles end-->
    </head>
     <body>	

<div class="gallery">
<div class="gallery_bot">
 <div class="row" style="margin-left:px;">
      <div style="height:13px"></div>
<table style="margin-left: auto;margin-right: auto;margin-top:-1150px;font-family: Verdana, Helvetica, sans-serif;font-size:19px;color:">
<?php
$scan = scandir("../../".$path); 
for ($i = 2; $i<count($scan); $i++) 
{ 
	$photo="../../".$path.$scan[$i];
	if($scan[$i]=="Thumbs.db")
	{
		$my=$i;
	}
	if($i==2 || $i==4 || $i==6 || $i==8 || $i==10 || $i==12 || $i==14 || $i==16 || $i==18)
	{
	echo "<tr>";
	}
	if($scan[$i]!="Thumbs.db")
	{
	?>
	<div class="box_img2" style="margin-right:-50px;">
	<td ;margin-top:;">
	<div class="g_size"><a href="<?php echo $photo?>"  class="pirobox_gal1" title="1st Project Image"><img src="<?php echo $photo?>" height="162" width="308" alt="" /></a></div>
	<br></td>
	<?php }
} 
?> 
	</div>	 </tr>
        </div>
       
    </div>
        
</div>

</div>
<div class="templatemo_footerg">
</div>
	
