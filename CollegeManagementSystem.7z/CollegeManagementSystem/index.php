<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html lang="en-US" xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>
	
<title>Vivekanand College Surat</title>
	
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	
<link rel="shortcut icon" href="css/images/logo1.png" />

	
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />


<script src="js/jquery-1.6.2.min.js" type="text/javascript" charset="utf-8"></script>
	<!--[if IE 6]>
		
<script src="js/DD_belatedPNG-min.js" type="text/javascript" charset="utf-8"></script>
	<![endif]-->



<script src="js/jquery.jcarousel.min.js" type="text/javascript" charset="utf-8"></script>
	
<script src="js/functions.js" type="text/javascript" charset="utf-8"></script>
</head>

<body>
	
<!-- Begin Wrapper -->
	<div id="wrapper">
		
<!-- Begin Header -->
		
<div id="header">
			
<body style="margin-bottom:80px;background-color: #c9bda7; 
	background-image: url(css/images/templatemo_body.jpg);">			
<div class="shell" style="margin-bottom:45px;">
			
<img src="css/images/logo1.png" width="" height="140" style="margin-bottom:105px;margin-left:-95px;margin-top:30px;">
<H6 style="margin-top:-250px;margin-left:50px;font-size:15px;color:#666666;display: block;">Managed By Abhinav Education Trust, Jahangirpura</h6>
<H6 style="margin-top:-18px;margin-left:600px;font-size:15px;color:#666666;" >Affiliated To Veer Narmad South Gujarat University</h6>
<H6 style="margin-top:40px;margin-left:75px;font-size:32px;color:#666666;font-weight:bold" >VIVEKANAND COLLEGE FOR BCA,BBA,B.COM,B.Ed,PTC </h6>
<br>
<H6 style="margin-top:px;margin-left:px;font-size:14px;color:#666666;" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;(Reg. No.E/4682/SURAT)</h6>			
</body>			
<div class="cl">&nbsp;</div>
				
		
</div>
			
<!-- End Shell -->
		
</div>
		<!-- End Header -->
		
<!-- Begin Navigation -->
		
<div id="navigation">
			
<!-- Begin Shell -->
			
<div class="shell">
				
<ul>
					
<li class="active"><a href="index.php" title="home">Home</a></li>

<li><a href="" title="Kids">About Us</a>

<div class="dd">
							
<ul>
<li><a href="about/mission.html" title="Drop down menu 1">mission</a></li>
								
<li><a href="about/college.php" title="Drop down menu 2">college</a></li>
								
<li>
<a href="about/management.html" title="Drop down menu 3">management</a>
</li>
<li>
<a href="about/creater.html" title="Drop down menu 3">Developers</a>
</li>	
</ul>
</div>
</li>	
<li><a href="#" title="Sports">Course</a>
<div class="dd">
							
<ul>
<li><a href="courses/bca.php" title="Drop down menu 1">BCA</a></li>
								
<li><a href="courses/bba.php" title="Drop down menu 2">BBA</a></li>
								
<li>
<a href="courses/bcom.php" title="Drop down menu 3">BCOM</a>
</li>
<li>
<a href="courses/bed.php" title="Drop down menu 3">BED</a>
</li>
<li>
<a href="courses/ptc.php" title="Drop down menu 3">PTC</a>
</li>			
</ul>
</div>
</li>							
<li><a href="" title="Kids">Faculty</a>

<div class="dd">
							
<ul>
<li><a href="faculty/bcafaclist.php" title="Drop down menu 1">BCA</a></li>
								
<li><a href="faculty/bbafaclist.php">BBA</a></li>
								
<li>
<a href="faculty/bcomfaclist.php" title="Drop down menu 3">BCOM</a>
</li>
<li><a href="faculty/bedfaclist.php" title="Drop down menu 2">BED</a></li>
								
<li>
<a href="faculty/ptcfaclist.php" title="Drop down menu 3">PTC</a>
</li>		
</ul>
</div>
</li>						
<li><a href="result/result.php" title="">Result</a></li>

<li><a href="" title="Kids">Attendance</a>

<div class="dd">
							
<ul>
<li><a href="attendance/showattendancebca.php" title="Drop down menu 1">BCA</a></li>
								
<li><a href="attendance/showattendancebba.php" title="Drop down menu 1">BBA</a></li>
						
<li><a href="attendance/showattendancebcom.php" title="Drop down menu 1">BCOM</a></li>

<li><a href="attendance/showattendancebed.php" title="Drop down menu 1">BED</a></li>
							
<li><a href="attendance/showattendanceptc.php" title="Drop down menu 1">PTC</a></li>

</ul>
</div>
</li>		
				


					
<li><a href="#" title="Football">Download</a>
						
<div class="dd">
							
<ul>
								
<li>
<a href="#" title="Drop down menu 3">Exam Time Table</a>
									
<div class="dd">
										
<ul>
											
<li><a href="download/examtimetable/bcaexamtimetable.php" title="Dr">BCA</a></li>
											
<li><a href="download/examtimetable/bbaexamtimetable.php" title="Drop down menu 2">BBA</a></li>
											
<li><a href="download/examtimetable/bcomexamtimetable.php" title="Drop down menu 3">BCOM</a></li>
											
<li><a href="download/examtimetable/bedexamtimetable.php" title="Drop down menu 4">BED</a></li>

<li><a href="download/examtimetable/ptcexamtimetable.php" title="Drop down menu 4">PTC</a></li>
											
</ul>
									
</div>
								</li>
								
<li>
<a href="#" title="Drop down menu 3">Syllabus</a>
									
<div class="dd">
										
<ul>
											
<li><a href="download/syllabus/bcasyllabus.php" title="Dr">BCA</a></li>
											
<li><a href="download/syllabus/bbasyllabus.php"  title="Drop down menu 2">BBA</a></li>
											
<li><a href="download/syllabus/bcomsyllabus.php"  title="Drop down menu 3">BCOM</a></li>
											
<li><a href="download/syllabus/bedsyllabus.php" title="Drop down menu 4">BED</a></li>

<li><a href="download/syllabus/ptcsyllabus.php" title="Drop down menu 4">PTC</a></li>
											
</ul>
									
</div>
								</li>
								
<li>
<a href="#" title="Drop down menu 3">Assignment</a>
									
<div class="dd">
										
<ul>
											
<li><a href="download/assignment/bcaassignment.php" title="Dr">BCA</a></li>
											
<li><a href="download/assignment/bbaassignment.php" title="Dr">BBA</a></li>
											
<li><a href="download/assignment/bcomassignment.php" title="Dr">BCOM</a></li>
												
<li><a href="download/assignment/bedassignment.php" title="Dr">BED</a></li>
	
<li><a href="download/assignment/ptcaassignment.php" title="Dr">PTC</a></li>
										
</ul>
									
</div>
							
</ul>
						
</div>
					
</li>
					
<li><a href="gallery/clggallery.php" title="">Photo Gallery</a>
</li>			
		
			
			
</ul>
				
<div class="cl">&nbsp;</div>
			
</div>
			<!-- End Shell -->
		
</div>
		<!-- End Navigation -->
		<!-- Begin Slider -->
		
<div id="slider" style="">
			
<!-- Begin Shell -->
			
<div class="shell">
				
<ul class="slider-items" >
					
<li>
		
<img src="css/images/9.jpg" width="1000" height="525" alt="Slide Image" />
						
</li>

<li>						
<img src="css/images/1.jpg"  width="1000" height="525" alt="Slide Image" />
						
</li>
	
<li>
						
<img src="css/images/3.jpg"  width="1000" height="525" alt="Slide Image" />
						
</li>
					
<li>
						
<img src="css/images/8.jpg"  width="1000" height="525" alt="Slide Image" />
						
</li>
					
<li>
		
<img src="css/images/22.jpg" width="1000" height="525" alt="Slide Image" />
						
</li>
	
<li>
		
<img src="css/images/15.jpg" width="1000" height="525" alt="Slide Image" />
						
</li>
				
</ul>
				
<div class="cl">&nbsp;
</div>
				
<div class="slider-nav">
									
</div>
			
</div>
			
<!-- End Shell -->
		
</div>
		
<link href="css/templatemo_style.css" rel="stylesheet" type="text/css" />




<div id="templatemo_main_top"></div>

<div id="templatemo_main_wrapper1">			
<div class="post" style="width:800px;margin-left:26px;">
<br>					
<center><h2 style="margin-left:12px;margin-top:;font-size:24px;">A message from your Director!</h2>
</center>	
<br>				
<img src="css/images/mssumathi.jpg" alt="Post Image" width="135" height="159"/>
					
<p style="color:#6E6E6E;font: 18px Arial, Helvetica, sans-serif;margin-left:12px;text-align:justify;">
<?php
$con=mysql_connect("localhost","root","");
if($con)
{
	mysql_select_db("vvkcollege",$con);
}
else
{
	echo "Connection is not Est"."<br>";
}
$res10=mysql_query("select info from collegeinfo_master where info_type='diretor msg';");
$row10=mysql_fetch_array($res10);
echo $row10['info'];
?>
<br><br>  <strong> <h3 style="font-size:22px;text-align:right;color:#87CEFA;margin-top:px;">Ms Sumathi Shenoy </p>
					</p>
					<div class="cl">&nbsp;</div>
						</div>
			<!-- End Content -->
							<div class="cl">&nbsp;</div>
			
<h2 style="margin-left:36px;width:800px;">			
<h2 style="margin-left:350px;margin-top:;width:500px;font-size:20px;"><center>A message from your I/C Principal (BCA)</center></h2>

<br>				
<img src="css/images/dipjaya.jpg" alt="Post Image" align="right" width="135" style="margin-left:10px;margin-right:10px;" height="159" />
					
<p style="color:#6E6E6E;font: 18px vardna, Helvetica, sans-serif;margin-left:340px;margin-right:50px;text-align:justify;"><?php $res10=mysql_query("select info from collegeinfo_master where info_type='principal msg';");
$row10=mysql_fetch_array($res10);
echo $row10['info'];
?><br><br>  <strong> <h3 style="font-size:22px;text-align:right;color:#87CEFA;margin-top:-10px;">Ms Dipjaya Patel </p>
			</p>
				
<h6 style="font-family: Arial, Helvetica, sans-serif;
    font-size: 18px;
    font-weight: normal;
    color: #ffffff;
    background: url(css/images/contact_but.png) no-repeat top left;
    text-align: center;
    width: 274px;
    height: 40px;
    padding-top: 14px;margin-top:-215px;margin-left:15px;">Event</h6>




<div   style="margin-top:-14px;margin-left:18px;height:18em;width:265px;-moz-border-radius: 1em 4em 1em 4em;
border-radius: 0em 0em 2em 2em;
border-bottom: 1px  black solid;border-left: 1px  black solid;border-right: 1px  black solid;font: 15px Arial, Helvetica, sans-serif;color:#666666;">
<div class="align-content">			
<marquee onmouseover="stop()"  onmouseout="start()" direction="up" align="center"  scrollamount="2"
            scrolldelay="1">
<ul>
<?php
$day=date("d");
$mon=date("m");
$year=date("Y");

$res=mysql_query("select * from event_master;");

while($row=mysql_fetch_array($res))
{
	$sdate=$row['start_date'];
	$edate=$row['end_date'];
	$syear=substr($sdate,0,4);
	$eyear=substr($edate,0,4);
	$mon=substr($sdate,5,2);
	$emon=substr($edate,5,2);
	$smon=substr($sdate,5,2);
	$sday=substr($sdate,8,2);
	$eday=substr($edate,8,2);
	if($eyear==$year)
	{
		if($emon==$mon)
		{
			if($eday>=$day)
			{
				$name=$row['event_name'];
				echo "<li style='margin-left:35px;'>"."<strong style='color:#454545;'>";
				echo $sday."/".$smon."/".$syear." :: ";
				echo $name;
				echo "</strong>";
				echo "<br>";
				echo "<div 'style=color:#008cc4;'>";
				echo $row['dis'];
				?>
				<img src="css/images/new.gif" style="margin-left:4px;">
				<?php
				echo "<br>";
				echo "<br>";
				echo "</li>";
				echo "</div>";
				
				
			}
		}
		else
		{
			if($emon>=$mon)
			{
				$name=$row['event_name'];
				echo "<li style='margin-left:35px;'>"."<strong style='color:#454545;'>";
				echo $sday."/".$smon."/".$syear." :: ";
				echo $name;
				echo "</strong>";
				echo "<br>";
				echo "<div 'style=color:#008cc4;'>";
				echo $row['dis'];
				?>
				<img src="css/images/new.gif" style="margin-left:4px;">
				<?php
				echo "<br>";
				echo "<br>";
				echo "</li>";
				echo "</div>";
			}
			else
			{
				
			}
		
		}	
	}
	else
	{
		if($eyear>=$year && $emon<$mon)
		{
		
				$name=$row['event_name'];
				echo "<li style='margin-left:35px;'>"."<strong style='color:#454545;'>";
				echo $sday."/".$smon."/".$syear." :: ";
				echo $name;
				echo "</strong>";
				echo "<br>";
				echo "<div 'style=color:#008cc4;'>";
				echo $row['dis'];
				?>
				<img src="css/images/new.gif" style="margin-left:4px;">
				<?php
				echo "<br>";
				echo "<br>";
				echo "</li>";
				echo "</div>";
				
		}
	}
}

?>
</li>
</ul>
</marquee>			
</div>

</div>

<div style="margin-top:100px;margin-left:60px;">
<h6 style="font-family: Arial, Helvetica, sans-serif;
    font-size: 18px;
    font-weight: normal;
    color: #ffffff;
    background: url(css/images/contact_but.png) no-repeat top left;
    text-align: center;
    width: 274px;
    height: 40px;
    padding-top: 14px;margin-left:-37px;">Fresh News</h6>

<div   style="margin-top:-14px;margin-left:-35px;height:18em;width:265px;-moz-border-radius: 1em 4em 1em 4em;
border-radius: 0em 0em 2em 2em;
border-bottom: 1px  black solid;border-left: 1px  black solid;border-right: 1px  black solid;font: 15px Arial, Helvetica, sans-serif;color:#666666;">
			<div class="align-content">
<marquee onmouseover="stop()"  onmouseout="start()" direction="up" align="center"  scrollamount="2"
            scrolldelay="1">
<?php
$day=date("d");
$mon=date("m");
$year=date("Y");
$con=mysql_connect("localhost","root","");
if($con)
{
	mysql_select_db("vvkcollege",$con);
}
else
{
	echo "Connection is not Est"."<br>";
}
$res=mysql_query("select * from news_master;");

while($row=mysql_fetch_array($res))
{
	$sdate=$row['start_date'];
	$edate=$row['end_date'];
	$syear=substr($sdate,0,4);
	$eyear=substr($edate,0,4);
	$mon=substr($sdate,5,2);
	$emon=substr($edate,5,2);
	$smon=substr($sdate,5,2);
	$sday=substr($sdate,8,2);
	$eday=substr($edate,8,2);
	if($eyear==$year)
	{
		if($emon==$mon)
		{
			if($eday>=$day)
			{
				$name=$row['news_name'];
				$id=$row['down_id'];
				if($id>0)
				{
				$res1=mysql_query("select * from download_master where down_id=$id;");
				$row1=mysql_fetch_array($res1);
				$path="../../../../../".$row1['path'];
				?><a href="<?php echo $path?>"><?php
				echo "<li style='margin-left:35px;'>"."<strong style=';'>";
				echo $sday."/".$smon."/".$syear." :: ";
				echo $name;
				echo "</strong>";
				echo "<br>";
				echo "<div 'style=color:;'>";
				echo $row['dis'];
				?>
				<img src="css/images/new.gif" style="margin-left:4px;">
				<?php
				echo "<br>";
				echo "<br>";
				echo "</li>";
				echo "</a>";
				echo "</div>";
				}
				else
				{
				$name=$row['news_name'];
				echo "<li style='margin-left:35px;'>"."<strong style='color:#454545;'>";
				echo $sday."/".$smon."/".$syear." :: ";
				echo $name;
				echo "</strong>";
				echo "<br>";
				echo "<div 'style=color:#008cc4;'>";
				echo $row['dis'];
				?>
				<img src="css/images/new.gif" style="margin-left:4px;">
				<?php
				echo "<br>";
				echo "<br>";
				echo "</li>";
				echo "</a>";
				echo "</div>";
				}
				
				
			}
		}
		else
		{
			if($emon>=$mon)
			{
				$name=$row['news_name'];
				$id=$row['down_id'];
				if($id>0)
				{
				$res1=mysql_query("select * from download_master where down_id=$id;");
				$row1=mysql_fetch_array($res1);
				$path="../../../../../".$row1['path'];
				?><a href="<?php echo $path?>"><?php
				echo "<li style='margin-left:35px;'>"."<strong style=';'>";
				echo $sday."/".$smon."/".$syear." :: ";
				echo $name;
				echo "</strong>";
				echo "<br>";
				echo "<div 'style=color:;'>";
				echo $row['dis'];
				?>
				<img src="css/images/new.gif" style="margin-left:4px;">
				<?php
				echo "<br>";
				echo "<br>";
				echo "</li>";
				echo "</a>";
				echo "</div>";
				}
				else
				{
				$name=$row['news_name'];
				echo "<li style='margin-left:35px;'>"."<strong style='color:#454545;'>";
				echo $sday."/".$smon."/".$syear." :: ";
				echo $name;
				echo "</strong>";
				echo "<br>";
				echo "<div 'style=color:#008cc4;'>";
				echo $row['dis'];
				?>
				<img src="css/images/new.gif" style="margin-left:4px;">
				<?php
				echo "<br>";
				echo "<br>";
				echo "</li>";
				echo "</a>";
				echo "</div>";
				}
				
			}
			else
			{
				
			}
		
		}	
	}
	else
	{
		if($eyear>=$year && $emon<$mon)
		{
		
			$name=$row['news_name'];
				$id=$row['down_id'];
				if($id>0)
				{
				$res1=mysql_query("select * from download_master where down_id=$id;");
				$row1=mysql_fetch_array($res1);
				$path="../../../../../".$row1['path'];
				?><a href="<?php echo $path?>"><?php
				echo "<li style='margin-left:35px;'>"."<strong style=';'>";
				echo $sday."/".$smon."/".$syear." :: ";
				echo $name;
				echo "</strong>";
				echo "<br>";
				echo "<div 'style=color:;'>";
				echo $row['dis'];
				?>
				<img src="css/images/new.gif" style="margin-left:4px;">
				<?php
				echo "<br>";
				echo "<br>";
				echo "</li>";
				echo "</a>";
				echo "</div>";
				}
				else
				{
				$name=$row['news_name'];
				echo "<li style='margin-left:35px;'>"."<strong style='color:#454545;'>";
				echo $sday."/".$smon."/".$syear." :: ";
				echo $name;
				echo "</strong>";
				echo "<br>";
				echo "<div 'style=color:#008cc4;'>";
				echo $row['dis'];
				?>
				<img src="css/images/new.gif" style="margin-left:4px;">
				<?php
				echo "<br>";
				echo "<br>";
				echo "</li>";
				echo "</a>";
				echo "</div>";
				}
			
		}
	}
}

?>
</li>
</ul>
</marquee>	
</div>	
<div style="margin-top:-237px;margin-left:630px;width: 253px;
	float: left;
	margin-left: ;">	
<h6 style="font-family: Arial, Helvetica, sans-serif;
    font-size: 18px;
    font-weight: normal;
    color: #ffffff;
    background: url(css/images/contact_but.png) no-repeat top left;
    text-align: center;
    width: 274px;
    height: 40px;
    padding-top: 14px;margin-left:-65px;">Contact Information</h6>
<div style="margin-top:-15px;margin-left:-61px;height:18em;width:265px;-moz-border-radius: 1em 4em 1em 4em;
border-radius: 0em 0em 2em 2em;
border-bottom: 1px  black solid;border-left: 1px  black solid;border-right: 1px  black solid;color:#454545;text-align:left">
                <div style="height:15px"></div>
                <div style="padding-left:10px">
                    <div  class="box_us">
                          <div  class="box_us_l">
                            <img src="css/images/fish_us1.png" alt="" />
                          </div>
                          <div  class="box_us_r">
                                <b class="lh">Near Jakat Naka,Surat Olpad Road

, Jahangirpura,

Surat - 395 005</b>
                          </div>
                          <div style="clear: both; height:10px;"></div>
                    </div> 
			<br>
                    <div  class="box_us">
                          <div  class="box_us_l">
                            <img src="css/images/fish_us2.png" alt="" />
                          </div>
                          <div  class="box_us_r">
                                <b class="lh">Phone: (0261) 2775488, 3295488<br />
							Fax: 2915488
                                </b>
                          </div>
                          <div style="clear: both; height:10px;"></div>
                    </div>
			<br>
                    <div  class="box_us">
                          <div  class="box_us_l">
                            <img src="css/images/fish_us3.png" alt="" />
                          </div>
                          <div  class="box_us_r">
                                <b class="lh" >E-mail: vivekanandsg@indiatimes.com</b>
                          </div>
                          <div style="clear: both; height:10px;"></div>
                    </div>
           		</div>
   		</div>


<h6 style="font-family: Arial, Helvetica, sans-serif;
    font-size: 18px;
    font-weight: normal;
    color: #ffffff;
    background: url(css/images/contact_but.png) no-repeat top left;
    text-align: center;
    width: 274px;
    height: 40px;
    padding-top: 14px;margin-left:-350px;margin-top:-50px;">You Are Visitor No :

				<?php
				$count_my_page = ("hitcounter.txt");
				$hits = file($count_my_page);
				$hits[0] ++;
				$fp = fopen($count_my_page , "w");
				fputs($fp , "$hits[0]");
				fclose($fp);
				echo $hits[0];
				 ?>

</h6>





</div></div>








</div> <!-- end of main -->
</div> <!-- end of main wrapper -->
<div id="templatemo_footer" style="margin-bottom:-10px;">
	</div>
	
    <div class="cleaner"></div>
<div id="footercopy"  style="margin-bottom:-50px;">
	<p>Copyright &copy; 2012 Vivekanad college. All rights reserved.<br />

	Developed  By:Nakrani Chetan L.,Vasani Amit B.,Devani Hardik J.</p>

</div>
</div> <!-- end of footer -->

</body>
</html>